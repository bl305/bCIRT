PYTHONPATH=".:tests:$PYTHONPATH" django-admin.py test core --settings=settings
