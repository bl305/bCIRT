=======
Results
=======

.. currentmodule:: import_export.results

Result
------

.. autoclass:: import_export.results.Result
   :members:
