==================
Temporary storages
==================

.. currentmodule:: import_export.tmp_storages

TempFolderStorage
-----------------

.. autoclass:: import_export.tmp_storages.TempFolderStorage
   :members:


CacheStorage
------------

.. autoclass:: import_export.tmp_storages.CacheStorage
   :members:


MediaStorage
------------

.. autoclass:: import_export.tmp_storages.MediaStorage
   :members:
