from django.apps import AppConfig


class reportsConfig(AppConfig):
    name = 'reports'

