from import_export import resources
from .models import UpdatePackage


class UpdatePackageResource(resources.ModelResource):
    class Meta:
        model = UpdatePackage
