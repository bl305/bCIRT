#!/bin/bash
find . -path "*/__pycache__/*.pyc" -delete
