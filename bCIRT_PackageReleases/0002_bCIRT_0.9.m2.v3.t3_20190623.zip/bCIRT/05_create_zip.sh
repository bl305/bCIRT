#!/bin/bash
zip -e ../bCIRT.zip ./*
