#!/bin/bash
rm ./db.sqlite3
