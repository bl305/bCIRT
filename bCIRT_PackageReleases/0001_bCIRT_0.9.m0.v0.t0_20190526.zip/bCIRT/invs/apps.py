from django.apps import AppConfig


class InvestigationsConfig(AppConfig):
    name = 'invs'
