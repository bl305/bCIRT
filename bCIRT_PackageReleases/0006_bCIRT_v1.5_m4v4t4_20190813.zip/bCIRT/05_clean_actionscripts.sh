#!/bin/bash
find . -path "./tasks/actions/*" -delete
