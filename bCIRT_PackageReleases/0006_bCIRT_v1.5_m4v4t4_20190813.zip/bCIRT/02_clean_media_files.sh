#!/bin/bash
find ./media/ -not -path ./media/icons/searchicon.png -type f -delete
find ./log/ -type f -delete
