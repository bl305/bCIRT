from django.apps import AppConfig


class KnowledgebaseConfig(AppConfig):
    name = 'knowledgebase'
