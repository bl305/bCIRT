Welcome to bCIRT's documentation!
=================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   :name: mastertoc

   overview
   installation


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
